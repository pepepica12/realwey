# Proyecto `realway-nuevo`

Servidor Express básico para despliegue en Railway. Estructura idéntica a `realwey`, creado desde cero para trazabilidad y reversibilidad total.
